package com.ssh.dao.impl;

import com.ssh.dao.IOrderDAO;
import com.ssh.entity.OrderEntity;

import java.util.List;

public class OrderDAO implements IOrderDAO {
    @Override
    public void save(OrderEntity orderEntity) {

    }

    @Override
    public void delete(OrderEntity orderEntity) {

    }

    @Override
    public void update(OrderEntity orderEntity) {

    }

    @Override
    public List<OrderEntity> findAll() {
        return null;
    }
}
