package com.ssh.service;

public interface IOrderService {
}
